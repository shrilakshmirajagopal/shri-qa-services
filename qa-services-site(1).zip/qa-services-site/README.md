# Shri QA Services Website

A free static one-page professional services website.

## Before publishing
1. Open `index.html` in a text editor.
2. Replace `shrilakshmirajagopal@gmail.com` with your email address.
3. Replace `https://www.linkedin.com/in/shri-lakshmi-rajagopal-a5012428/` with your LinkedIn profile URL.
4. Review the metrics and wording.

## Preview
Double-click `index.html` to open it in a browser.

## Publish free
### GitHub Pages
- Create a GitHub repository.
- Upload `index.html`, `styles.css`, and `script.js`.
- Open Settings → Pages → Deploy from branch → main/root.

### Netlify
- Go to Netlify Drop.
- Drag the entire folder into the upload area.

### Cloudflare Pages
- Create a Pages project and connect the GitHub repository.
- No build command is required.

This site uses Google Fonts. The remainder is plain HTML, CSS, and JavaScript.
